/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AnalisadorSemantico;

import java.util.ArrayList;
import AnalisadorLexicos.*;
import AnalisadorSintatico.*;
/**
 *
 * @author santi
 */
public class AnaSem {
     public boolean existe(ArrayList <TbSimbolo> variaveis, TbSimbolo var, int linha) {
        
        for(int i = 0; i < variaveis.size(); i++){
           
        if (variaveis.get(i).variavel.equals(var.variavel) && variaveis.get(i).numEsc == var.numEsc 
            && variaveis.get(i).escopo.equals(var.escopo)) {
            System.out.println("Erro Semantico na linha "+linha+" a variavel "+var.variavel+" já foi declarada");
            return true;
        }
        }
        
        return false;
    }
    
    public int posicao(ArrayList <TbSimbolo> variaveis, String var) {
     
        for(int i = 0; i < variaveis.size(); i++){
           
            if (variaveis.get(i).variavel.equals(var) ) {
                return i;
                
            }
        }
       
        return -1;
    }
   
    public boolean verDeclaracao(ArrayList <TbSimbolo> variaveis, String var,int esc ,int linha) {
        int i;
        for(i = 0; i < variaveis.size(); i++){
           
            if (variaveis.get(i).variavel.equals(var) && (variaveis.get(i).numEsc == esc
                    || variaveis.get(i).escopo.equalsIgnoreCase("global"))) {
                return true;
            }
        }
        
       System.out.println("Erro Semantico na linha "+linha+" a variavel "+var+" não foi declarada");
        return false;
    }

    public void operacaoLogica() {
    }
}

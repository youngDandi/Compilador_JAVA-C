/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AnalisadorSintatico;

import AnalisadorLexicos.AnalisadorSimbolos;
import AnalisadorLexicos.LexemasTokens;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author santi
 */
public class Main2 {

   public static AnalisadorSimbolos AS= new AnalisadorSimbolos();
   
    public static ArrayList<LexemasTokens> tokenLexema = new ArrayList<>();
    
    public static void main(String[] args) throws IOException {
        Scanner ler = new Scanner(System.in);
        int n = 0;
        do
        {
            System.out.println("1-LER DO FICHEIRO: ");
            System.out.println("2-ESCREVER DO PROGRAMA: ");
            System.out.println("3-SAIR: ");
            System.out.print("R: ");
            n=ler.nextInt();
            switch(n)
            {
                case 1:
                {
                    AS.LerDoFicheiro(2);
                    System.out.println("");
                    tokenLexema= AS.RetornaValores();
                     Analise a= new Analise(tokenLexema);
                     a.goal();
                    
                    break;
                }
                
                case 2:
                {
                    
                    int verificador=1, cont=1;
                    String codigo="", codigofonte="";
                     System.out.println("----------DIGITE O SEU CODIGO FONTE----------------");
                     System.out.println("OBS: DIGITE (run)  SE QUISER COMPILAR O SEU CODIGO.");
                     System.out.println("");
                     System.out.println("Inicio");
                     
                     ler.nextLine();
                    while(verificador==1)
                    {
                       
                        System.out.print(cont+" "); 
                        codigofonte=ler.nextLine()+"\n";
                        
                        if(codigofonte.contains("run"))
                        {
                            break;
                        }
                        
                        cont++;
                        codigo=codigo+codigofonte;
                    }
                    
                    AS.EscreverNoPrograma(codigo, 2);
                    tokenLexema= AS.RetornaValores();
                    Analise a= new Analise(tokenLexema);
                     a.goal();
                    break;
                }
            }
        }while(n!=3);
    }
    
}

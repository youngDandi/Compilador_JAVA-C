/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AnalisadorSintatico;

import AnalisadorLexicos.AnalisadorSimbolos;
import AnalisadorLexicos.LexemasTokens;
import AnalisadorLexicos.Token;
import AnalisadorSemantico.AnaSem;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author santi
 */
public class Analise {

    
    private final static int TAMANHO_BUFFER = 10;
    public static ArrayList<LexemasTokens> bufferTokens;
    boolean chegouNoFim = false;
    ArrayList <TbSimbolo> tabela; 
    AnaSem semantico;
    TbSimbolo tb;
    String  tipoDados,tipoVar, escopo, var;
    int contEsc;
    int contErr;
    int contErrS;
    int i;
    
    public Analise(ArrayList<LexemasTokens>  lex) {
        this.semantico = new AnaSem();
        bufferTokens = lex;
        tabela = new ArrayList<>();
        this.contEsc = 0;
        this.contErr = 0;
        this.contErrS = 1;
        this.i=0;
        
    }

   

//    void match(LexemasTokens tipo) {
//        
//        if (bufferTokens.get(i).getToken().equals(tipo)) {
//            System.out.println("Match  " + bufferTokens.get(i));
//            for(int i=0; i<bufferTokens.size(); i++)
//            {
//                if ((i+1) == bufferTokens.size()) {
//                chegouNoFim = true;
//                if(contErr == 0 && contErrS == 1){
//                    System.out.println("Análise sintatica realizada com sucesso");
//                }
//                else{
//                    System.out.println("Análise comprometida, quantidade de erros "+(this.contErr+this.contErrS));
//                }
//                 
//            }
//            }
//        } else {
//            erroSintatico(tipo.toString()); 
//        }
//    }
    
    void match(String tipo) {
       
           
            
            if(bufferTokens.get(i).getToken()== Token.TOKEN_EOF)
            {
                chegouNoFim=true;
                return;
            }
            if (bufferTokens.get(i).getToken().equals(tipo)&& chegouNoFim==false) {
           
              
                
                this.i++;
                return;
                 
            }
            
        
        erroSintatico(tipo.toString());
    }
          
    
    
    void erroSintatico(String... tokensEsperados) {
        int line;
        if(bufferTokens.get(i-1).getLinha()<bufferTokens.get(i).getLinha())
        {
             line= bufferTokens.get(i).getLinha()-1;
        }
        else
        {
            line= bufferTokens.get(i).getLinha();
        }
        String mensagem = "Erro sintático na linha "+line+": esperando um dos seguintes (";
        for (int i = 0; i < tokensEsperados.length; i++) {
            mensagem += tokensEsperados[0];
          
            if (i < tokensEsperados.length - 1) {
                mensagem += ",";
            }
             break;
        }
        mensagem += "), mas foi encontrado " + bufferTokens.get(i).getToken();
        System.out.println(mensagem);
        this.contErr++;
      
    }
    
    public void goal(){
        program();
    }
    
    public void program(){
        externs();
    }
    
    public void externs(){
        if(bufferTokens.get(i).getToken().equals( Token.TOKEN_CHAR)
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_INT)
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_FLOAT)
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_VOID)
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_DOUBLE)
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_BOOLEAN)
           || bufferTokens.get(i).getToken().equals(Token.TOKEN_ID)){
            extern();
            externs();
        }
        else{
            lambda();
        }
    }
    
    public boolean lambda(){
       return true;
    }
    
    public void extern(){
        
        
        String esc, tipo;
        if(bufferTokens.get(i).getToken().equals( Token.TOKEN_CHAR)
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_INT)
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_FLOAT)
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_VOID)
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_DOUBLE)
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_BOOLEAN)
           ){
            this.tb = new TbSimbolo();
            this.escopo = "Global";
            this.tipoDados = type();
            restoextern();
        }
        else if( bufferTokens.get(i).getToken().equals( Token.TOKEN_ID)){
            match(Token.TOKEN_ID);
                    
            
            func();
        }
        else{
            erroSintatico((Token.TOKEN_CHAR).toString()
                          ,(Token.TOKEN_INT).toString()
                          ,(Token.TOKEN_FLOAT).toString()
                          ,(Token.TOKEN_VOID).toString()
                          ,(Token.TOKEN_DOUBLE).toString()
                          ,(Token.TOKEN_BOOLEAN).toString()
                          ,(Token.TOKEN_ID).toString());
        }
    }
    
    public void restoextern(){
        
       
        if(bufferTokens.get(i).getToken().equals( Token.TOKEN_ID)){
            this.var = bufferTokens.get(i).getLexema();
            match(Token.TOKEN_ID);
            
            restoExtern2();
        }
        else if(bufferTokens.get(i).getToken().equals( Token.TOKEN_MULT)){
            match(Token.TOKEN_MULT);
            if(bufferTokens.get(i).getToken().equals( Token.TOKEN_ID)){
               this.var = bufferTokens.get(i).getLexema();
               tipoVar = "Ponteiro";
            }
            match(Token.TOKEN_ID);
            restoVars();
        }
        else{
            erroSintatico((Token.TOKEN_ID).toString()
                          ,(Token.TOKEN_MULT).toString());
        }
    }
    
    public void restoExtern2(){
        
        
        if(bufferTokens.get(i).getToken().equals( Token.TOKEN_ABRE_PARENTESES_CURVO)){
            func();
        }
        else{
            restodclr();
            restoVars();
            match(Token.TOKEN_PONTO_VIRGULA);
        }

    }
    
    public void var(){
        
        
        
        if(bufferTokens.get(i).getToken().equals( Token.TOKEN_CHAR)
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_INT)
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_FLOAT)  
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_DOUBLE)
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_BOOLEAN)){
            this.tb = new TbSimbolo();
            this.escopo = "Local";
            this.tipoDados = type();
            
            dclr();
            
            restoVars();
       }
        else{
            erroSintatico((Token.TOKEN_CHAR).toString()
                          ,(Token.TOKEN_INT).toString()
                          ,(Token.TOKEN_FLOAT).toString()
                         
                          ,(Token.TOKEN_DOUBLE).toString()
                          ,(Token.TOKEN_BOOLEAN).toString()
                         );
        }
    }
    
    public void restoVars(){
        
        
       if(bufferTokens.get(i).getToken().equals( Token.TOKEN_VIRGULA)){
           this.tb = new TbSimbolo();
           match(Token.TOKEN_VIRGULA);
           dclr();
           restoVars();
       }
       else{
           lambda();
           if(escopo.equals("global")){
                tb.numEsc = this.contEsc;
                tb.tipoVar = "Simples";
                tb.escopo = this.escopo;
                tb.tipoDados = this.tipoDados;
                tb.variavel = this.var;
                if(!semantico.existe(tabela, tb, bufferTokens.get(i).getLinha())){
                    tabela.add(tb);
                }
                else{
                    contErrS++;
                }
           
           }
       }
    }
    
    public String type(){
        
        
       String tipoDados = null;
       
       if(bufferTokens.get(i).getToken().equals( Token.TOKEN_CHAR)){
           tipoDados = bufferTokens.get(i).getLexema();
           match(Token.TOKEN_CHAR);
       }
       else if(bufferTokens.get(i).getToken().equals( Token.TOKEN_FLOAT)){
           tipoDados = bufferTokens.get(i).getLexema();
           match(Token.TOKEN_FLOAT);
       }
       else if(bufferTokens.get(i).getToken().equals( Token.TOKEN_INT)){
           tipoDados = bufferTokens.get(i).getLexema();
            match(Token.TOKEN_INT);
       }
       else if(bufferTokens.get(i).getToken().equals( Token.TOKEN_BOOLEAN)){
           tipoDados = bufferTokens.get(i).getLexema();
          match(Token.TOKEN_BOOLEAN);
       }
       else if(bufferTokens.get(i).getToken().equals( Token.TOKEN_DOUBLE)){
           tipoDados = bufferTokens.get(i).getLexema();
           match(Token.TOKEN_DOUBLE);
       }
       else{
           match(Token.TOKEN_VOID);
       }
       
       return tipoDados;
    }
    
    
    
    public void dclr(){
     
        
       if(bufferTokens.get(i).getToken().equals( Token.TOKEN_ID)){
           this.var = bufferTokens.get(i).getLexema();
           match(Token.TOKEN_ID);
           restodclr();
           restoExpr(this.var);
       }
       else if(bufferTokens.get(i).getToken().equals( Token.TOKEN_MULT)) {
           match(Token.TOKEN_MULT);
            if(bufferTokens.get(i).getToken().equals( Token.TOKEN_ID)){
                this.var = bufferTokens.get(i).getLexema();
                this.tipoVar = "Ponteiro";
            }
           match(Token.TOKEN_ID);
           restoExpr(this.var);
       }
       else{
           erroSintatico((Token.TOKEN_ID).toString()
                          ,(Token.TOKEN_MULT).toString());
       }
       
    }
    
    public void restodclr(){
        
        
       if(bufferTokens.get(i).getToken().equals( Token.TOKEN_ABRE_PARENTESES_RETO)){
         match(Token.TOKEN_ABRE_PARENTESES_RETO);
           restodclr2();
       }
       else{  
           tb.numEsc = this.contEsc;
           tb.tipoVar = "Simples";
           tb.escopo = this.escopo;
           tb.tipoDados = this.tipoDados;
           tb.variavel = this.var;
           if(!semantico.existe(tabela, tb, bufferTokens.get(i).getLinha())){
                tabela.add(tb);
                
           }
           else{
               contErrS++;
           }
          
       }
    }
    
    public void restodclr2(){
        
        
       if(bufferTokens.get(i).getToken().equals( Token.TOKEN_FECHA_PARENTESES_RETO)){
          match(Token.TOKEN_FECHA_PARENTESES_RETO);
           tb.numEsc = this.contEsc;
           this.tb.tipoVar = "Vector";
           tb.escopo = this.escopo;
           tb.tipoDados = this.tipoDados;
           tb.variavel = this.var;
            if(!semantico.existe(tabela, tb, bufferTokens.get(i).getLinha())){
                    tabela.add(tb);
                }
                else{
                    contErrS++;
                }
       }
       else if(bufferTokens.get(i).getToken().equals( Token.TOKEN_INTEIRO)){
           match(Token.TOKEN_INTEIRO);
           if(bufferTokens.get(i).getToken().equals( Token.TOKEN_FECHA_PARENTESES_RETO)){
               tb.numEsc = this.contEsc;
               this.tb.tipoVar = "Vector";
               tb.escopo = this.escopo;
               tb.tipoDados = this.tipoDados;
               tb.variavel = this.var;
                if(!semantico.existe(tabela, tb, bufferTokens.get(i).getLinha())){
                    tabela.add(tb);
                }
                else{
                    contErrS++;
                } 
           }
                match(Token.TOKEN_FECHA_PARENTESES_RETO);
       }
       else{
           erroSintatico((Token.TOKEN_FECHA_PARENTESES_RETO).toString()
                          ,(Token.TOKEN_INTEIRO).toString());
       }
    }
    
    public void dcls(){
        
        
       if(bufferTokens.get(i).getToken().equals( Token.TOKEN_CHAR)
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_INT)
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_FLOAT )
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_DOUBLE)
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_BOOLEAN)
         ){
           var();
           match(Token.TOKEN_PONTO_VIRGULA);
           dcls();
       }
       else{
           lambda();
       }
    }
    
    public void func(){
        
        
        if(bufferTokens.get(i).getToken().equals( Token.TOKEN_ABRE_PARENTESES_CURVO)){
            fargs();
           match(Token.TOKEN_ABRECHAVETA);
           while(bufferTokens.get(i).getToken().equals( Token.TOKEN_CHAR)
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_INT)
            || bufferTokens.get(i).getToken().equals( Token.TOKEN_FLOAT )
            || bufferTokens.get(i).getToken().equals( Token.TOKEN_DOUBLE)
            || bufferTokens.get(i).getToken().equals( Token.TOKEN_BOOLEAN)){
                dcls();
                stmts();
        }
            match(Token.TOKEN_FECHA_CHAVETA);
            this.contEsc++;
        }
        else{
            erroSintatico((Token.TOKEN_ABRE_PARENTESES_CURVO).toString());
        }
    }
    
    public void fargs(){
        
        match(Token.TOKEN_ABRE_PARENTESES_CURVO);
     
       restofargs();
    }
    
    public void restofargs(){
        
        
        if(bufferTokens.get(i).getToken().equals( Token.TOKEN_CHAR)
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_INT)
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_FLOAT)
          
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_DOUBLE)
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_BOOLEAN)
           ){
           args();
           match(Token.TOKEN_FECHA_PARENTESES_CURVO);
       }
        else if(bufferTokens.get(i).getToken().equals( Token.TOKEN_FECHA_PARENTESES_CURVO)){
        match(Token.TOKEN_FECHA_PARENTESES_CURVO);
       }
        else{
            erroSintatico((Token.TOKEN_FECHA_PARENTESES_CURVO).toString()
                          ,(Token.TOKEN_INT).toString()
                          ,(Token.TOKEN_CHAR).toString()
                          ,(Token.TOKEN_FLOAT).toString()
                          ,(Token.TOKEN_DOUBLE).toString()
                          ,(Token.TOKEN_BOOLEAN).toString());
        }
    }
    
    public void args(){
        
        
        if(bufferTokens.get(i).getToken().equals( Token.TOKEN_CHAR)
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_INT)
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_FLOAT)
           
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_DOUBLE)
           || bufferTokens.get(i).getToken().equals( Token.TOKEN_BOOLEAN)){
            type();
            dclr();
            restofargs();
        }
        else{
            erroSintatico((Token.TOKEN_FECHA_PARENTESES_CURVO).toString()
                          ,(Token.TOKEN_INT).toString()
                          ,(Token.TOKEN_CHAR).toString()
                          ,(Token.TOKEN_FLOAT).toString()
                          
                          ,(Token.TOKEN_BOOLEAN).toString());
        }
    }
    
    public void restoargs(){
        
        
        if(bufferTokens.get(i).getToken().equals( Token.TOKEN_VIRGULA)){
           match(Token.TOKEN_VIRGULA);
           args();
       }
       else{
           lambda();
       }
    }
    
    public void stmts(){
        
         
        if(bufferTokens.get(i).getToken().equals( Token.TOKEN_IF)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_WHILE)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_DO  ) 
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_FOR)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_RETURN)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_BREAK)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_CONTINUE)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_ABRECHAVETA)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_PONTO_VIRGULA)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_NOTI)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_AND)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_MULT)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_SUBTRAI)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_SOMA)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_NOT)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_DUPLA_SOMA)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_DUPLA_SUBTRACAO)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_ID)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_ABRE_PARENTESES_CURVO)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_INTEIRO)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_FLOATI)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_ASPAS_DUPLAS)){
            stmt();
            stmts();
       }
       else{
           lambda();
       }
    }
    
    public void stmt(){
          
       
        if(bufferTokens.get(i).getToken().equals( Token.TOKEN_IF)){
           match(Token.TOKEN_IF);
           match(Token.TOKEN_ABRE_PARENTESES_CURVO);
           expro();
           match(Token.TOKEN_FECHA_PARENTESES_CURVO);
          stmt();
           restoIf();
        }
        else if(bufferTokens.get(i).getToken().equals( Token.TOKEN_WHILE)){
          match(Token.TOKEN_WHILE);
          match(Token.TOKEN_ABRE_PARENTESES_CURVO);
          expro();
          match(Token.TOKEN_FECHA_PARENTESES_CURVO);
           stmt();
        }
        else if(bufferTokens.get(i).getToken().equals( Token.TOKEN_DO)){
          match(Token.TOKEN_DO);
           stmt();           
           match(Token.TOKEN_WHILE);
           match(Token.TOKEN_ABRE_PARENTESES_CURVO);
           expro();
           match(Token.TOKEN_FECHA_PARENTESES_CURVO);
           
        }
        else if(bufferTokens.get(i).getToken().equals( Token.TOKEN_FOR)){
        match(Token.TOKEN_FOR);
        match(Token.TOKEN_ABRE_PARENTESES_CURVO);
           expro();
            match(Token.TOKEN_PONTO_VIRGULA);
           expro();
           match(Token.TOKEN_PONTO_VIRGULA);
           expro();
           match(Token.TOKEN_FECHA_PARENTESES_CURVO);
           stmt();
        }
        else if(bufferTokens.get(i).getToken().equals( Token.TOKEN_RETURN)){
           match(Token.TOKEN_RETURN);
            restoReturn();
        }
        else if(bufferTokens.get(i).getToken().equals( Token.TOKEN_BREAK)){
            match(Token.TOKEN_BREAK);
           match(Token.TOKEN_PONTO_VIRGULA);
        }
        else if(bufferTokens.get(i).getToken().equals( Token.TOKEN_CONTINUE)){
            match(Token.TOKEN_CONTINUE);
           match(Token.TOKEN_PONTO_VIRGULA);
        }
        else if(bufferTokens.get(i).getToken().equals( Token.TOKEN_ABRECHAVETA)){
            block();
        }
        else if(bufferTokens.get(i).getToken().equals( Token.TOKEN_PONTO_VIRGULA)){
            match(Token.TOKEN_PONTO_VIRGULA);
        }
        else{
            expr();
            match(Token.TOKEN_PONTO_VIRGULA);
            
        }
    }
    
    public void restoIf(){
        
        
        if(bufferTokens.get(i).getToken().equals( Token.TOKEN_ELSE)){
            match(Token.TOKEN_ELSE);
            stmt();
            match(Token.TOKEN_PONTO_VIRGULA);
        }
        else{
            lambda();
        }
    }
    
    
    public void restoReturn(){
        
        
        if(bufferTokens.get(i).getToken().equals( Token.TOKEN_NOTI)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_AND)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_MULT)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_SUBTRAI)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_NOT)
           
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_DUPLA_SOMA)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_DUPLA_SUBTRACAO)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_ID)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_ABRE_PARENTESES_CURVO)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_INTEIRO)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_FLOATI)
           ||bufferTokens.get(i).getToken().equals( Token.TOKEN_ASPAS_DUPLAS)){
            expr();
            match(Token.TOKEN_PONTO_VIRGULA);
        }
        else if(bufferTokens.get(i).getToken().equals( Token.TOKEN_PONTO_VIRGULA)){
            match(Token.TOKEN_PONTO_VIRGULA);
        }
        else{
                erroSintatico((Token.TOKEN_NOTI).toString()
                          ,(Token.TOKEN_AND).toString()
                          ,(Token.TOKEN_MULT).toString()
                          ,(Token.TOKEN_SUBTRAI).toString()
                          ,(Token.TOKEN_NOTI).toString()
                          ,(Token.TOKEN_DUPLA_SOMA).toString()
                          ,(Token.TOKEN_DUPLA_SUBTRACAO).toString()
                          ,(Token.TOKEN_ID).toString()
                          ,(Token.TOKEN_ABRE_PARENTESES_CURVO).toString()
                          ,(Token.TOKEN_INTEIRO).toString()
                          ,(Token.TOKEN_FLOATI).toString()
                          ,(Token.TOKEN_ASPAS_DUPLAS).toString()
                          ,(Token.TOKEN_PONTO_VIRGULA).toString());
        }
    }
    
    public void block(){   
        
     match(Token.TOKEN_ABRECHAVETA);
        stmts();
       match(Token.TOKEN_FECHA_CHAVETA);
    }
   
    public void lval(){
        
        
        if(bufferTokens.get(i).getToken().equals( Token.TOKEN_ID)){
            match(Token.TOKEN_ID);
            restoLval();
        }
        else if(bufferTokens.get(i).getToken().equals( Token.TOKEN_MULT)){
            match(Token.TOKEN_MULT);
            match(Token.TOKEN_ID);
            
        } 
        else{
            erroSintatico((Token.TOKEN_ID).toString()
                          ,(Token.TOKEN_MULT).toString());
        }
    }
     
    public void restoLval(){
        
        
        if(bufferTokens.get(i).getToken().equals( Token.TOKEN_ABRE_PARENTESES_RETO)){
            match(Token.TOKEN_ABRE_PARENTESES_RETO);
            expr();
            match(Token.TOKEN_FECHA_PARENTESES_RETO);
        }
        else{
            lambda();
        } 
    }
    
    public LexemasTokens expr(){
        
        LexemasTokens dir = null;
        LexemasTokens esq = null;
        if(bufferTokens.get(i).getToken().equals(Token.TOKEN_NOTI)
           || bufferTokens.get(i).getToken().equals(Token.TOKEN_AND)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_MULT)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_SUBTRAI)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_SOMA)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_NOTI)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_DUPLA_SOMA)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_DUPLA_SUBTRACAO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ID)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ABRE_PARENTESES_CURVO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_INTEIRO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_FLOATI)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_DUPLAS)){
            if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ID)){
                var = bufferTokens.get(i).getLexema();
            }
            or();
            restoExpr(var);
           
        }
        else{
            erroSintatico((Token.TOKEN_NOTI).toString()
                          ,(Token.TOKEN_AND).toString()
                          ,(Token.TOKEN_MULT).toString()
                          ,(Token.TOKEN_SUBTRAI).toString()
                          ,(Token.TOKEN_NOTI).toString()
                          ,(Token.TOKEN_DUPLA_SOMA).toString()
                          ,(Token.TOKEN_DUPLA_SUBTRACAO).toString()
                          ,(Token.TOKEN_ID).toString()
                          ,(Token.TOKEN_ABRE_PARENTESES_CURVO).toString()
                          ,(Token.TOKEN_INTEIRO).toString()
                          ,(Token.TOKEN_FLOATI).toString()
                          ,(Token.TOKEN_ASPAS_DUPLAS).toString()
                          );
        }
        
        return esq;
    }
    
    
    
    public boolean restoExpr(String var){
        
        if(bufferTokens.get(i).getToken().equals( Token.TOKEN_IGUAL)){
           semantico.verDeclaracao(tabela, var, contEsc, bufferTokens.get(i).getLinha());
            match(Token.TOKEN_IGUAL);
           
            if(bufferTokens.get(i).getToken().equals( Token.TOKEN_ID)){               
            if(semantico.verDeclaracao(tabela, bufferTokens.get(i).getLexema(), contEsc, bufferTokens.get(i).getLinha())){
                    if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals(tabela.get(semantico.posicao(tabela,bufferTokens.get(i).getLexema())).tipoDados)){
                     
                       tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                    }
                    else{
                        System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                    }
                    
                }
                
            }
            else if(bufferTokens.get(i).getToken().equals( Token.TOKEN_INTEIRO)){
               
                if(semantico.posicao(tabela, var) >= 0){
                    
                if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("int")){
                    
                    tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                }
                 else{
                        System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                }
                }
            }
            else if(bufferTokens.get(i).getToken().equals( Token.TOKEN_FLOATI)){
               
                if(semantico.posicao(tabela, var) > 0){
                if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("float")){
                    tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                }
                else{
                        System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                }
             }
            }
            else if(bufferTokens.get(i).getToken().equals( Token.TOKEN_ASPAS_DUPLAS)){
                    
                if(semantico.posicao(tabela, var) >= 0){
                   
                if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("Aspas Duplas")){
                    tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                }
                 else{
                        System.out.println("Erro sintatico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                    }
                }
            }
            else if(bufferTokens.get(i).getToken().equals( Token.TOKEN_ASPAS_SIMPLES)){
                
                if(semantico.posicao(tabela, var) >= 0){
                if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("Aspas Simples")){
                    tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                }
                 else{
                        System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                    }
                }
            }
            
            expr();
        }
        else{
            lambda();
        }
        
        return true;
    }
        
    
    public LexemasTokens or(){
        LexemasTokens tok = and();
        restoOr();
        
        return tok;
    }
    
    public void restoOr(){
        if(bufferTokens.get(i).getToken().equals(Token.TOKEN_OR_OR)){
            match(Token.TOKEN_OR_OR);
            or();
        }
        else{
            lambda();
        }
    }
    
     public LexemasTokens and(){
        LexemasTokens tok = not(); 
        restoAnd();
       
        return tok;
    }
    
    public void restoAnd(){
        if(bufferTokens.get(i).getToken().equals(Token.TOKEN_AND_AND)){
            match(Token.TOKEN_AND_AND);
            and();
        }
        else{
            lambda();
        }
    }
    
    
    
    public LexemasTokens not(){
        LexemasTokens tok = null;
        if(bufferTokens.get(i).getToken().equals(Token.TOKEN_NOT)){
           match(Token.TOKEN_NOT);
            not();
        }
        else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_AND)
           
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_MULT)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_SUBTRAI)
            ||bufferTokens.get(i).getToken().equals(Token.TOKEN_SOMA)    
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_NOTI)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_DUPLA_SOMA)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_DUPLA_SUBTRACAO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ID)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ABRE_PARENTESES_CURVO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_INTEIRO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_FLOATI)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_DUPLAS)){
            
            cfator();
        }
        else{
            erroSintatico((Token.TOKEN_NOTI).toString()
                          ,(Token.TOKEN_AND_AND).toString()
                          ,(Token.TOKEN_MULT).toString()
                          ,(Token.TOKEN_SUBTRAI).toString()
                          ,(Token.TOKEN_NOTI).toString()
                          ,(Token.TOKEN_DUPLA_SOMA).toString()
                          ,(Token.TOKEN_DUPLA_SUBTRACAO).toString()
                          ,(Token.TOKEN_ID).toString()
                          ,(Token.TOKEN_ABRE_PARENTESES_CURVO).toString()
                          ,(Token.TOKEN_INTEIRO).toString()
                          ,(Token.TOKEN_FLOATI).toString()
                          ,(Token.TOKEN_ASPAS_DUPLAS).toString());  
        }
         return tok;
        
    }
       

    public boolean cfator(){
        boolean b = false;
        var = bufferTokens.get(i).getLexema();
            orbin();
            b = restocfator();
       
        return b;
    }
    
    public boolean restocfator(){
       
        if(bufferTokens.get(i).getToken().equals(Token.TOKEN_IGUAL_IGUAL)){
            semantico.verDeclaracao(tabela, var, contEsc, bufferTokens.get(i).getLinha());
            match(Token.TOKEN_IGUAL_IGUAL);
            if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ID) || bufferTokens.get(i).getToken().equals(Token.TOKEN_INTEIRO) 
               ||bufferTokens.get(i).getToken().equals(Token.TOKEN_FLOATI) || bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_DUPLAS)
               || bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_SIMPLES)){
                if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ID)){
                if(semantico.verDeclaracao(tabela, bufferTokens.get(i).getLexema(), contEsc, bufferTokens.get(i).getLinha())){
                    if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals(tabela.get(semantico.posicao(tabela,bufferTokens.get(i).getLexema())).tipoDados)){
                     
                        tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                    }
                    else{
                        System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                    }
                    
                }
                
            }
            else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_INTEIRO)){
               
                if(semantico.posicao(tabela, var) >= 0){
                    
                if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("int")){
                    
                    tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                }
                 else{
                        System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                }
                }
            }
            else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_FLOATI)){
               
                if(semantico.posicao(tabela, var) > 0){
                if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("float")){
                    tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                }
                else{
                        System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                }
             }
            }
            else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_DUPLAS)){
                    
                if(semantico.posicao(tabela, var) >= 0){
                   
                if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("Aspas Duplas")){
                    tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                }
                 else{
                        System.out.println("Erro sintatico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                    }
                }
            }
            else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_SIMPLES)){
                
                if(semantico.posicao(tabela, var) >= 0){
                if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("Aspas Simples")){
                    tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                }
                 else{
                        System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                    }
                }
            }
               orbin();
            }else{
                erroSintatico((Token.TOKEN_ID).toString(),
                                (Token.TOKEN_INTEIRO).toString());
            }
        }
        else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_DIFERENTE)){
           match(Token.TOKEN_DIFERENTE);
            if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ID) || bufferTokens.get(i).getToken().equals(Token.TOKEN_INTEIRO) 
               ||bufferTokens.get(i).getToken().equals(Token.TOKEN_FLOATI) || bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_DUPLAS)
               || bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_SIMPLES)){
                if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ID)){
                if(semantico.verDeclaracao(tabela, bufferTokens.get(i).getLexema(), contEsc, bufferTokens.get(i).getLinha())){
                    if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals(tabela.get(semantico.posicao(tabela,bufferTokens.get(i).getLexema())).tipoDados)){
                     
                        tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                    }
                    else{
                        System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                    }
                    
                }
                
            }
            else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_INTEIRO)){
               
                if(semantico.posicao(tabela, var) >= 0){
                    
                if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("int")){
                    
                    tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                }
                 else{
                        System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                }
                }
            }
            else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_FLOATI)){
               
                if(semantico.posicao(tabela, var) > 0){
                if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("float")){
                    tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                }
                else{
                        System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                }
             }
            }
            else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_DUPLAS)){
                    
                if(semantico.posicao(tabela, var) >= 0){
                   
                if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("Aspas Duplas")){
                    tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                }
                 else{
                        System.out.println("Erro sintatico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                    }
                }
            }
            else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_SIMPLES)){
                
                if(semantico.posicao(tabela, var) >= 0){
                if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("Aspas Simples")){
                    tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                }
                 else{
                        System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                    }
                }
            }
                orbin();
            }else{
                erroSintatico((Token.TOKEN_ID).toString(),
                                (Token.TOKEN_INTEIRO).toString());
            }
        }
        else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_MENOR_IGUAL)){
          match(Token.TOKEN_MENOR_IGUAL);
            if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ID) || bufferTokens.get(i).getToken().equals(Token.TOKEN_INTEIRO )
               ||bufferTokens.get(i).getToken().equals(Token.TOKEN_FLOATI) || bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_DUPLAS)
               || bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_SIMPLES)){
                if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ID)){
                if(semantico.verDeclaracao(tabela, bufferTokens.get(i).getLexema(), contEsc, bufferTokens.get(i).getLinha())){
                    if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals(tabela.get(semantico.posicao(tabela,bufferTokens.get(i).getLexema())).tipoDados)){
                     
                        tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                    }
                    else{
                        System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                    }
                    
                }
                
            }
            else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_INTEIRO) ){
               
                if(semantico.posicao(tabela, var) >= 0){
                    
                if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("int")){
                    
                    tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                }
                 else{
                        System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                }
                }
            }
            else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_FLOATI)){
               
                if(semantico.posicao(tabela, var) > 0){
                if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("float")){
                    tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                }
                else{
                        System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                }
             }
            }
            else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_DUPLAS)){
                    
                if(semantico.posicao(tabela, var) >= 0){
                   
                if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("Aspas Duplas")){
                    tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                }
                 else{
                        System.out.println("Erro sintatico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                    }
                }
            }
            else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_SIMPLES)){
                
                if(semantico.posicao(tabela, var) >= 0){
                if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("Aspas Simples")){
                    tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                }
                 else{
                        System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                    }
                }
            }
              orbin();
            }else{
                erroSintatico((Token.TOKEN_ID).toString(),
                                (Token.TOKEN_INTEIRO).toString());
            }
        }
        else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_MAIOR_IGUAL)){
           match(Token.TOKEN_MAIOR_IGUAL);
           if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ID) || bufferTokens.get(i).getToken().equals(Token.TOKEN_INTEIRO )
               ||bufferTokens.get(i).getToken().equals(Token.TOKEN_FLOATI) || bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_DUPLAS)
               || bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_SIMPLES)){
                if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ID)){
                if(semantico.verDeclaracao(tabela, bufferTokens.get(i).getLexema(), contEsc, bufferTokens.get(i).getLinha())){
                    if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals(tabela.get(semantico.posicao(tabela,bufferTokens.get(i).getLexema())).tipoDados)){
                     
                        tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                    }
                    else{
                        System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                    }
                    
                }
                
            }
            else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_INTEIRO)){
               
                if(semantico.posicao(tabela, var) >= 0){
                    
                if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("int")){
                    
                    tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                }
                 else{
                        System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                }
                }
            }
            else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_FLOATI)){
               
                if(semantico.posicao(tabela, var) > 0){
                if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("float")){
                    tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                }
                else{
                        System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                }
             }
            }
            else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_DUPLAS)){
                    
                if(semantico.posicao(tabela, var) >= 0){
                   
                if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("Aspas Duplas")){
                    tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                }
                 else{
                        System.out.println("Erro sintatico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                    }
                }
            }
            else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_SIMPLES)){
                
                if(semantico.posicao(tabela, var) >= 0){
                if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("Aspas Simples")){
                    tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                }
                 else{
                        System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                    }
                }
            }
               orbin();
            }else{
                erroSintatico((Token.TOKEN_ID).toString(),
                                (Token.TOKEN_INTEIRO).toString());
            }
        }
        else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_MENOR)){
           match(Token.TOKEN_MENOR);
            if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ID) || bufferTokens.get(i).getToken().equals(Token.TOKEN_INTEIRO) 
               ||bufferTokens.get(i).getToken().equals(Token.TOKEN_FLOATI) || bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_DUPLAS)
               || bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_SIMPLES)){
                
                if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ID)){
                    if(semantico.verDeclaracao(tabela, bufferTokens.get(i).getLexema(), contEsc, bufferTokens.get(i).getLinha())){
                        if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals(tabela.get(semantico.posicao(tabela,bufferTokens.get(i).getLexema())).tipoDados)){
                     
                            tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                        }
                        else{
                          System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                            contErrS++;
                        }   
                    }
                
                }
                else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_INTEIRO)){
               
                    if(semantico.posicao(tabela, var) >= 0){
                    
                        if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("int")){
                    
                            tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                        }
                        else{
                          System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                            contErrS++;
                        }
                    }
                }
                else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_FLOATI)){
               
                    if(semantico.posicao(tabela, var) > 0){
                        if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("float")){
                            tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                        }
                        else{
                          System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                            contErrS++;
                        }
                    }
                }
                else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_DUPLAS)){
                    
                   if(semantico.posicao(tabela, var) >= 0){
                   
                        if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("Aspas Duplas")){
                            tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                    }
                    else{
                        System.out.println("Erro sintatico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                    }
                }
            }
            else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_SIMPLES)){
                
                if(semantico.posicao(tabela, var) >= 0){
                    if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("Aspas Simples")){
                        tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                    }
                    else{
                        System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                        contErrS++;
                    }
                }
            }
               orbin();
            }else{
                erroSintatico((Token.TOKEN_ID).toString(),
                                (Token.TOKEN_INTEIRO).toString());
            }
        }
        else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_MAIOR)){
            
          match(Token.TOKEN_MAIOR);
            if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ID) || bufferTokens.get(i).getToken().equals(Token.TOKEN_INTEIRO )
               ||bufferTokens.get(i).getToken().equals(Token.TOKEN_FLOATI) || bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_DUPLAS)
               || bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_SIMPLES)){
                
                if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ID)){
                    if(semantico.verDeclaracao(tabela, bufferTokens.get(i).getLexema(), contEsc, bufferTokens.get(i).getLinha())){
                        if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals(tabela.get(semantico.posicao(tabela,bufferTokens.get(i).getLexema())).tipoDados)){
                     
                            tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                        }
                        else{
                            System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                            contErrS++;
                        }
                    }
                }
                else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_INTEIRO)){
               
                    if(semantico.posicao(tabela, var) >= 0){
                    
                        if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("int")){
                    
                            tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                        }
                        else{
                            System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                            contErrS++;
                        }
                    }
                }
                else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_FLOATI)){
               
                    if(semantico.posicao(tabela, var) > 0){
                    
                       if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("float")){
                            tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                        }
                        else{
                            System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                            contErrS++;
                        }
                    }
                }
                else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_DUPLAS)){
                    
                    if(semantico.posicao(tabela, var) >= 0){
                   
                        if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("Aspas Duplas")){
                            tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                        }
                        else{
                            System.out.println("Erro sintatico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                            contErrS++;
                        }
                    }
                }
                else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_SIMPLES)){
                
                    if(semantico.posicao(tabela, var) >= 0){
                        if(tabela.get(semantico.posicao(tabela, var)).tipoDados.equals("Aspas Simples")){
                            tabela.get(semantico.posicao(tabela, var)).valorAtrib = bufferTokens.get(i).getLexema();
                        }
                        else{
                            System.out.println("Erro semantico na linha "+bufferTokens.get(i).getLinha()+" valores incompativeis");
                            contErrS++;
                        }
                    }
                }
               orbin();
            }else{
                erroSintatico((Token.TOKEN_ID).toString(),
                                (Token.TOKEN_INTEIRO).toString());
            }
        }
        else{
            lambda();
        }
        
        return false;
    }
    
    public LexemasTokens orbin(){
        LexemasTokens tok = xorbin();
        restoOrbin();
        
        return tok;
    }
    
    public void restoOrbin(){
        if(bufferTokens.get(i).getToken().equals(Token.TOKEN_OR)){
            match(Token.TOKEN_OR);
            xorbin();
            restoOrbin();
        }
        else{
            lambda();
        }
    }
    
    public LexemasTokens xorbin(){
        LexemasTokens tok = andbin();
        restoXorbin();
        
        return tok;
    }
    
    public void restoXorbin(){
        if(bufferTokens.get(i).getToken().equals(Token.TOKEN_XOR)){
            match(Token.TOKEN_XOR);
            andbin();
            restoXorbin();
        }
        else{
            lambda();
        }
    }
    
    public LexemasTokens andbin(){
        LexemasTokens tok = rola();
        restoAndbin();
        
        return tok;
    }
    
    public void restoAndbin(){
        if(bufferTokens.get(i).getToken().equals(Token.TOKEN_AND)){
            match(Token.TOKEN_AND);
            rola();
            restoAndbin();
        }
        else{
            lambda();
        }
    }
    
    public LexemasTokens rola(){
        LexemasTokens tok = soma();
        
        
        return tok;
    }
    
   /* public void restoRola(){
        if(bufferTokens.get(i).nome == TipoToken.TOK_LEFTSHIFT){
            match(TipoToken.TOK_LEFTSHIFT);
            soma();
            restoRola();
        }
        else if(bufferTokens.get(i).nome == TipoToken.TOK_RIGHTSHIFT){
            match(TipoToken.TOK_RIGHTSHIFT);
            soma();
            restoRola();
        }
        else{
            lambda();
        }
    }
    */
    public LexemasTokens soma(){
        LexemasTokens tok = mult();
        restoSoma();
  
        return tok;
    }
    
    public void restoSoma(){
        if(bufferTokens.get(i).getToken().equals(Token.TOKEN_SOMA)){
            match(Token.TOKEN_SOMA);
            mult();
            restoSoma();
        }
        else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_SUBTRAI)){
            match(Token.TOKEN_SUBTRAI);
            mult();
            restoSoma();
        }
        else{
            lambda();
        }
    }
    
    public LexemasTokens mult(){
        LexemasTokens tok = ender();
        restoMult();
        
        return tok;
    }
    
    public void restoMult(){
        if(bufferTokens.get(i).getToken().equals(Token.TOKEN_MULT)){
            match(Token.TOKEN_MULT);
            ender();
            restoMult();
        }
        else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_DIV)){
            match(Token.TOKEN_DIV);
            ender();
            restoMult();
        }
        else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_MOD)){
            match(Token.TOKEN_MOD);
            ender();
            restoMult();
        }
        else{
            lambda();
        }
    }
    
    public LexemasTokens ender(){
        LexemasTokens tok = null;
        if(bufferTokens.get(i).getToken().equals(Token.TOKEN_AND)){
         match(Token.TOKEN_AND);
            lval();
        }
        else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_MULT)){
           match(Token.TOKEN_MULT);
            ender();
        }
        else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_SUBTRAI)
                || bufferTokens.get(i).getToken().equals(Token.TOKEN_SOMA)
               || bufferTokens.get(i).getToken().equals(Token.TOKEN_NOTI  )       
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_DUPLA_SOMA)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_DUPLA_SUBTRACAO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ID)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ABRE_PARENTESES_CURVO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_INTEIRO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_FLOATI)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_DUPLAS)){
 
            tok = uno();
        }
        
        return tok;
    }
    
    public LexemasTokens uno(){
        LexemasTokens tok = null;
        if(bufferTokens.get(i).getToken().equals(Token.TOKEN_SUBTRAI)){
            match(Token.TOKEN_SUBTRAI);
            uno();
        }
        else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_SOMA)){
            match(Token.TOKEN_SOMA);
            uno();
        }
        else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_NOTI    )     
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_DUPLA_SOMA)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_DUPLA_SUBTRACAO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ID)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ABRE_PARENTESES_CURVO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_INTEIRO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_FLOATI)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_DUPLAS)){
            
            tok = notbin();
        }
        
        return tok;
    }
    
    public LexemasTokens notbin(){
        LexemasTokens tok = null;
        if(bufferTokens.get(i).getToken().equals(Token.TOKEN_NOTI)){
            match(Token.TOKEN_NOTI);
            notbin();
        }
        else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_DUPLA_SOMA)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_DUPLA_SUBTRACAO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ID)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ABRE_PARENTESES_CURVO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_INTEIRO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_FLOATI)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_DUPLAS)){
            
            tok = incpre();
        }
        return tok;
    }
    
    public LexemasTokens incpre(){
        LexemasTokens tok = null;
        if(bufferTokens.get(i).getToken().equals(Token.TOKEN_DUPLA_SOMA)){
         match(Token.TOKEN_DUPLA_SOMA);
            lval();
        }
        else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_DUPLA_SUBTRACAO)){
            match(Token.TOKEN_DUPLA_SUBTRACAO);
            lval();
        }
        else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ID)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ABRE_PARENTESES_CURVO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_INTEIRO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_FLOATI)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_DUPLAS)){
            
            tok = incpos();
        }
        
        return tok;
    }
    
     public LexemasTokens incpos(){
        LexemasTokens tok = null;
        if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ID)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ABRECHAVETA)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_INTEIRO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_FLOATI)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_DUPLAS)){
            tok = fator();   
            restoIncpos();
        }
        
        return tok;
    }
     
    public void restoIncpos(){
        if(bufferTokens.get(i).getToken().equals(Token.TOKEN_DUPLA_SOMA)){
            
            match(Token.TOKEN_DUPLA_SOMA);
        }
        else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_DUPLA_SUBTRACAO)){
          
            match(Token.TOKEN_DUPLA_SUBTRACAO);
        }
        else{
            lambda();
        }
    }
     
    public LexemasTokens fator(){
        LexemasTokens tok = null; 
        if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ID)){
            tok = bufferTokens.get(i);
            match(Token.TOKEN_ID);

            restoFator1();
        }
        else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ABRE_PARENTESES_CURVO)){
           match(Token.TOKEN_ABRE_PARENTESES_CURVO);
            expr();
            match(Token.TOKEN_FECHA_PARENTESES_CURVO);
        }
        else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_INTEIRO)){
            tok = bufferTokens.get(i);
            match(Token.TOKEN_INTEIRO);
        }
        else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_FLOATI)){
            tok = bufferTokens.get(i);
            match(Token.TOKEN_FLOATI);
        }
        else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_DUPLAS)){
            tok = bufferTokens.get(i);
            match(Token.TOKEN_ASPAS_DUPLAS);
        }
        return tok;
    }
    
    public void restoFator1(){
        if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ABRE_PARENTESES_CURVO)){
            match(Token.TOKEN_ABRE_PARENTESES_CURVO);
            restoFator2();
        }
        else if(bufferTokens.get(i).getToken().equals(Token.TOKEN_ABRECHAVETA)){
            match(Token.TOKEN_ABRECHAVETA);
            expr();
            match(Token.TOKEN_FECHA_CHAVETA);
               }
        else{
            lambda();
        }
    }
    
    public void restoFator2(){
        if(bufferTokens.get(i).getToken().equals(Token.TOKEN_FECHA_PARENTESES_CURVO)){
            match(Token.TOKEN_FECHA_PARENTESES_CURVO);
        }
        else  if(bufferTokens.get(i).getToken().equals(Token.TOKEN_NOTI)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_AND)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_MULT)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_SUBTRAI)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_SOMA)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_NOTI)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_DUPLA_SOMA)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_DUPLA_SUBTRACAO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ID)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ABRE_PARENTESES_CURVO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_INTEIRO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_FLOATI)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_DUPLAS)){
            exprs();
           match(Token.TOKEN_FECHA_PARENTESES_CURVO);
        }
        else{
            erroSintatico((Token.TOKEN_FECHA_PARENTESES_CURVO).toString()
                          ,(Token.TOKEN_NOTI).toString()
                          ,(Token.TOKEN_AND).toString()
                          ,(Token.TOKEN_MULT).toString()
                          ,(Token.TOKEN_SUBTRAI).toString()
                          ,(Token.TOKEN_NOTI).toString()
                          ,(Token.TOKEN_DUPLA_SOMA).toString()
                          ,(Token.TOKEN_DUPLA_SUBTRACAO).toString()
                          ,(Token.TOKEN_ID).toString()
                          ,(Token.TOKEN_ABRE_PARENTESES_CURVO).toString()
                          ,(Token.TOKEN_INTEIRO).toString()
                          ,(Token.TOKEN_FLOATI).toString()
                          ,(Token.TOKEN_ASPAS_DUPLAS).toString()
                          ,(Token.TOKEN_PONTO_VIRGULA).toString());
        }
    }
    
    public void exprs(){
        expr();
        restoExprs();
        
    }
    
    public void restoExprs(){
        if(bufferTokens.get(i).getToken().equals(Token.TOKEN_VIRGULA)){
            match(Token.TOKEN_VIRGULA);
            expr();
        }
        else{
            lambda();
        }
    }
     
    public void expro(){
        
        if(bufferTokens.get(i).getToken().equals(Token.TOKEN_NOT)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_AND)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_MULT)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_SUBTRAI)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_SOMA)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_NOTI)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_DUPLA_SOMA)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_DUPLA_SUBTRACAO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ID)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ABRE_PARENTESES_CURVO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_INTEIRO)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_FLOATI)
           ||bufferTokens.get(i).getToken().equals(Token.TOKEN_ASPAS_DUPLAS)){
            expr();
        }
        else{
            lambda();
        }
        restocfator();
    }
    
    
}


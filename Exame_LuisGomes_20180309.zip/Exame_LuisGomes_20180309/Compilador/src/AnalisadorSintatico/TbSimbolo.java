/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AnalisadorSintatico;

/**
 *
 * @author santi
 */
public class TbSimbolo {
    public int numEsc;
    public String escopo;
    public String tipoDados;
    public String tipoVar;
    public String valorAtrib;
    public String variavel;
}

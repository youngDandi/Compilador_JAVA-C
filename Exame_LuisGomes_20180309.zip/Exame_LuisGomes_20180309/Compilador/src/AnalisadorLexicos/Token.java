/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AnalisadorLexicos;

/**
 *
 * @author santi
 */
public class Token {
    // Tipos de Dados
   public static String TOKEN_BYTE="byte";
    
    public static String TOKEN_SHORT="short"; 
    
    public static String TOKEN_CHAR="char";
    
    public static String TOKEN_INT="int";
    
    public static String TOKEN_LONG="long";
    
    public static String TOKEN_FLOAT="float";
    
    public static String TOKEN_DOUBLE="double";
    
    public static String TOKEN_BOOLEAN="bool";
    
    public static String TOKEN_INTEIRO="VALOR_INTEIRO";
    
    public static String TOKEN_FLOATI="VALOR_REAL";
    
    
    
    //Unidades de compilação
     public static String TOKEN_INCLUDE="include";
     
     public static String TOKEN_AUTO="auto"; 
    
     //        
    public static String TOKEN_BREAK="break";
    
    public static String TOKEN_CASE="case";
    
    public static String TOKEN_CONST="const"; 
    
    public static String TOKEN_CONTINUE="continue"; 
    
    public static String TOKEN_DEFAULT="default"; 
    
    public static String TOKEN_DO="do";  
    
    public static String TOKEN_ELSE="else";
    
    public static String TOKEN_ENUM="enum";
    
    public static String TOKEN_EXTERN="extern"; 
    
    public static String TOKEN_FOR="for"; 
    
    public static String TOKEN_GOTO="goto";
    
    public static String TOKEN_IF="if";
    
    public static String TOKEN_RETURN="return";
    
    public static String TOKEN_REGISTER="register";
    
    public static String TOKEN_SIGNED="signed";
    
    public static String TOKEN_SIZEOF="sizeof"; 
    
    public static String TOKEN_STATIC="static";
    
    public static String TOKEN_STRUCT="struct"; 
    
    public static String TOKEN_SWITCH="switch";
    
    public static String TOKEN_TYPEDEF="typedef"; 
    
    public static String TOKEN_UNION="union"; 
    
    public static String TOKEN_UNSIGNED="unsigned"; 
    
    public static String TOKEN_VOID="void";
    
    public static String TOKEN_VOLATILE="volatile"; 
    
    public static String TOKEN_WHILE="while";
    
    public static String TOKEN_NULL="NULL";
    
    public static String TOKEN_MALLOC="malloc";
    
    public static String TOKEN_CALLOC="calloc";
    
    public static String TOKEN_REALLOC="realloc";
    
    public static String TOKEN_PRINTF="printf";
    
     public static String TOKEN_SCANF="scanf";
     
     public  static String TOKEN_PUTS="puts";
      
     public   static String TOKEN_GETS="gets";
    
     public   static String TOKEN_DEFINE="define";
       
     
    public static String TOKEN_PALAVRA_RESERVADA="["+TOKEN_BYTE+"]["+TOKEN_WHILE+"]["+TOKEN_VOID+"]["+TOKEN_CONTINUE+"["
    +TOKEN_ENUM+"]["+TOKEN_EXTERN+"]["+TOKEN_SIGNED+"]["+TOKEN_SWITCH+"]["+TOKEN_SIZEOF+"]["+TOKEN_RETURN+"]["+TOKEN_TYPEDEF+"]["
    + TOKEN_UNION+"]["+TOKEN_UNSIGNED+"]["+TOKEN_IF+"]["+TOKEN_GOTO+"]["+TOKEN_FOR+"]["+TOKEN_ELSE+"]["+TOKEN_DO+"]["
            +TOKEN_DEFAULT+"]["+TOKEN_CONST+"]["+TOKEN_CASE+"]["+TOKEN_BREAK+"]["+TOKEN_STATIC+"]["+TOKEN_VOLATILE+"]["
            +TOKEN_SHORT+"]["+TOKEN_CHAR+"]["+TOKEN_INT+"]["+TOKEN_LONG+"]["+TOKEN_FLOAT+"]["
    +TOKEN_DOUBLE+"]["+TOKEN_BOOLEAN+"]["+TOKEN_INCLUDE+"]["+TOKEN_AUTO+"]["+TOKEN_INTEIRO+"]["+TOKEN_FLOATI+"]["+TOKEN_NULL+"]["
            +TOKEN_MALLOC+"]["+TOKEN_CALLOC+"]["+TOKEN_REALLOC+"]["+TOKEN_STRUCT+"]["+TOKEN_PRINTF+"]["+TOKEN_SCANF+"]["
            +TOKEN_PUTS+"]["+TOKEN_GETS+"]["+TOKEN_REGISTER+"]["+TOKEN_DEFINE+"]";
    //
    public static String TOKEN_TIPOS_PRIMITIVOS="["+TOKEN_BYTE+"]["+TOKEN_SHORT+"]["+TOKEN_CHAR+"]["+TOKEN_INT+"]"
            + "["+TOKEN_LONG+"]["+TOKEN_FLOAT+"]["+TOKEN_DOUBLE+"]["+TOKEN_BOOLEAN+"]["+TOKEN_INTEIRO+"]["+TOKEN_FLOATI+"]";
    
    
    
    
public static String TOKEN_ID = "IDENTIFICADOR";
public static String TOKEN_ABRE_PARENTESES_CURVO = "ABRE PARENTESES CURVO";
public static String TOKEN_FECHA_PARENTESES_CURVO = "FECHA PARENTESES CURVO";
public static String TOKEN_ABRE_PARENTESES_RETO = "ABRE PARENTESES RECTO";
public static String TOKEN_FECHA_PARENTESES_RETO = "FECHA PARENTESES RECTO";
public static String TOKEN_ABRECHAVETA = "ABRE CHAVETA";
public static String TOKEN_FECHA_CHAVETA = "FECHA CHAVETA";
public static String TOKEN_DOIS_PONTOS = "DOIS PONTOS";
public static String TOKEN_PONTO_VIRGULA = "PONTO E VIRGULA";
public static String TOKEN_VIRGULA = "VIRGULA";
public static String TOKEN_PONTO = "PONTO";
public static String TOKEN_MAIOR_IGUAL = "MAIOR IGUAL";
public static String TOKEN_MAIOR = "MAIOR";
public static String TOKEN_MAIOR_MAIOR = "MAIOR MAIOR";
public static String TOKEN_MENOR_IGUAL = "MENOR IGUAL";
public static String TOKEN_MENOR = "MENOR";
public static String TOKEN_MENOR_MENOR = "MENOR MENOR";
public static String TOKEN_IGUAL_IGUAL = "IGUAL IGUAL";
public static String TOKEN_IGUAL = "IGUAL";
public static String TOKEN_COMENTARIO_LINEAR = "COMENTÁRIO LINEAR";
public static String TOKEN_COMENTARIO_MULT="COMENTARIO MULTI LINHA";
public static String TOKEN_DIVIDIR_ATRIBUIR = "DIVEDE E ATRIBUI";
public static String TOKEN_MULTIPLICAR_ATRIBUIR = "MULTIPLICA E ATRIBUI";
public static String TOKEN_SOMAR_ATRIBUIR = "SOMA E ATRIBUI";
public static String TOKEN_SUBTRAIR_ATRIBUIR = "SUBTRAI E ATRIBUI";
public static String TOKEN_MOD_A = "RESTO DA DIVISÃO E ATRIBUI";
public static String TOKEN_SOMA = "SOMA";
public static String TOKEN_DUPLA_SOMA="Dupla Soma";
public static String TOKEN_SUBTRAI = "SUBTRAI";
public static String TOKEN_DUPLA_SUBTRACAO="Dupla Subtração";
public static String TOKEN_MULT = "MULTIPLICAÇÃO";
public static String TOKEN_DIV = "DIVISÃO";
public static String TOKEN_MOD = "RESTO DA DIVISÃO";
public  static String TOKEN_INCREMENTO = "INCREMENTO";
public static String TOKEN_DECREMENTO = "DECREMENTO";
public static String TOKEN_NOT = "NEGAÇÃO";
public static String TOKEN_DIFERENTE = "DIFERENTE";
public static String TOKEN_AND = "and bit a bit";
public static String TOKEN_AND_AND = "and";
public static String TOKEN_OR = "or bit a bit";
public static String TOKEN_OR_OR = "or";
public static String TOKEN_XOR = "xor";
public static String TOKEN_INTERROGACAO = "OPERADOR TERNARIO";
public static String TOKEN_RESERVADA="Palavra reservada";
public static String TOKEN_ASPAS_DUPLAS="Aspas Duplas";
public static String TOKEN_ASPAS_SIMPLES="Aspas Simples";
public static String TOKEN_NOTI="Negacao";
public static String TOKEN_CARDINAL="cardinal";
public static String TOKEN_EOF="fim";
public static String TOKEN_COMANDO="["+TOKEN_ABRE_PARENTESES_CURVO+"]["+TOKEN_ID+"]["+TOKEN_IF+"]["+TOKEN_WHILE+"]"
            + "["+TOKEN_DO+"]";

public static String TOKEN_COMANDO_BASICO="["+TOKEN_ABRE_PARENTESES_CURVO+"]["+TOKEN_ID+"]";
public static String TOKEN_ITERACAO="["+TOKEN_WHILE+"]["+TOKEN_DO+"]";
}
